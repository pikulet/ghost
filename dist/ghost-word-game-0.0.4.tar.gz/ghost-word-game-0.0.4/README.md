# ghost
Python engine for the word game of ghost (as played on em)

`GhostGameEngine` manages multiple `GhostGame`

Used in telegram bot (in repository ghost-bot)
